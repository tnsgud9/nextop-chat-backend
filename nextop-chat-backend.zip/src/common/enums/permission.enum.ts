export enum Permission {
  ADMIN,
  USER,
}
