export interface Configuration {
  DB_URI: string;
  PORT: number;
  SECRET_TOKEN: string;
}
