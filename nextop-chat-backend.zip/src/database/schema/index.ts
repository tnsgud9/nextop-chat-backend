import { AuthSchema } from './auth.schema';

export const Schemas = {
  Auth: { name: 'Auth', schema: AuthSchema },
};
